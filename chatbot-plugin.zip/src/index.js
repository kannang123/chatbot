// index.js
import './styles.css';
import './script.js';
